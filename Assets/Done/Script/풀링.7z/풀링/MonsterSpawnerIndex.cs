﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterSpawnerIndex : MonoBehaviour
{
    public static MonsterSpawnerIndex instance;
    
    private Queue<enemy> poolingObjectQueue = new Queue<enemy>();   //큐 생성(순서대로 반환/저장)

    [Header("몬스터 스폰 위치 좌표 배열")]
    public Transform[] points;
    [Header("몬스터 프리팹 배열(순서)")]
    [SerializeField] private GameObject[] mosterPrb;    //인스턴스화 되어있는 프리팹 대기용
    [Header("몬스터 번호")]
    [SerializeField] int monsternum = 0;
    [Space(10f)]
    [Header("몬스터 발생 주기(sec)")]
    [SerializeField]float createTime = 0f;    //몬스터를 발생시킬 주기
    [Header("몬스터 발생 주기 타이머(확인용)")]
    [SerializeField] float temptime = 0;  //몬스터 발생주기 타이머 대용
    [Header("필드 존재 가능 최대 몬스터 수")]
    [SerializeField] int maxmonster = 5;    //필드에 존재할 수 있는 최대 몬스터 수
    [Header("필드 몬스터 수(확인용)")]
    [SerializeField] static private int monstercounter=0;    //필드 몬스터 카운터 대용

    // Use this for initialization
    private void Awake()
    {
        instance = this;    //싱글톤
        Initialize(3);     //초기에 미리 풀링
        monstercounter = 0;
    }

    private enemy CreateNewObject()
    {
        if (monsternum < mosterPrb.Length)  //준비된 몬스터 배열이 안끝났을때
        {
            Debug.Log("monsterNum:" + monsternum);
            int idx = Random.Range(1, points.Length);
            var newObj = Instantiate(mosterPrb[monsternum], points[idx].position, points[idx].rotation).GetComponent<enemy>();
            newObj.gameObject.SetActive(false); //비활성화
            monsternum += 1;
            return newObj;
        }
        else
        {
            return null;
        }
    }

    //미리 풀링할 오브젝트 생성
    private void Initialize(int count)
    {
        for (int i = 0; i < count; i++)
        {
            poolingObjectQueue.Enqueue(CreateNewObject()); 
        }
    }

    public static enemy GetObject()
    {
        if (instance.poolingObjectQueue.Count > 0) //아직 큐에 활성화 시킬 오브젝트가 남아있는 경우
        {
            var obj = instance.poolingObjectQueue.Dequeue();    //큐에서 오브젝트 반환
            obj.transform.SetParent(null);  //부모 해제
            obj.gameObject.SetActive(true); //활성화
            return obj;
        }
        else //큐에 활성화 시킬 오브젝트가 남아있지 않은 경우
        {
            var newobj = instance.CreateNewObject();    //비활성화된 프리팹을 생성
            newobj.transform.SetParent(null);   //부모 해제
            newobj.gameObject.SetActive(true);  //활성화
            return newobj;
        }
    }

    public static void ReturnObject(enemy _enemy)
    {
        _enemy.gameObject.SetActive(false); //비활성화
        _enemy.transform.SetParent(instance.transform); //인스턴스를 부모로 설정
        instance.poolingObjectQueue.Enqueue(_enemy);    //풀링큐에 비활성화된 오브젝트 넣기
        monstercounter -= 1;
    }


    void Update()
    {
        temptime+= Time.deltaTime;
        if (points.Length > 0)
        {
            if(monstercounter<maxmonster)
            {
                if(temptime>=createTime)    //몬스터 생성 주기만큼 temp타이머가 돌면 몬스터 생성
                {
                    CreateMonster();
                    monstercounter += 1;    //필드 몬스터 수 증가
                    temptime = 0;           //생성 주기 타이머 초기화
                }
               
            }
        }
    }

    void CreateMonster()
    {
        var monster = MonsterSpawnerIndex.GetObject();
        Debug.Log("몬스터 생성");
    }
}